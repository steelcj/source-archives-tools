# Dublin Core Complete Metadata Profile Test

This document is used to verify the plugin's behavior when a complete metadata set is present.

It should confirm that:

- All supported Dublin Core fields are accepted
- The plugin does not overwrite already-complete metadata
- The document body remains unchanged
