# Dublin Core Defaults Metadata Test

This document is used to verify that the Dublin Core plugin correctly applies the default configuration profile.

It should produce:

- All required Dublin Core fields
- The expected default Creator
- The expected default Language
- The expected License, Contributor, and RightsHolder values
