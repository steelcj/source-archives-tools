---
DC_Language: fr-QC
---

# Language Override Test

Plugin should NOT overwrite this language value.
