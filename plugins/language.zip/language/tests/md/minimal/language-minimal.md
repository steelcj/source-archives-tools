# Language Minimal Test

This document contains no metadata.
